<?php


class FlightPassenger
{
	public $type; //enum String | ADULT, CHILD, INFANT, SENIOR, YOUNG, STUDENT, DISABLED, MILITARY, TEACHER;
	public $count; //int
}