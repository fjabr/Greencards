<div class="row">
    <div class="col-md-12">
        <div class="panel panel-default">
            <div class="panel-heading">Hotelbeds Bookings</div>
            <div class="panel-body"><?php echo $content; ?></div>
            <div class="panel-footer"></div>
        </div>
    </div>
</div>