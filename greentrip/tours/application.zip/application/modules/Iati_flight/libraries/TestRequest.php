<?php


class TestRequest extends BaseRequest
{
	public static $METHOD = "GET";
	public static $SERVICE_URL_PATH = "test/sample";
	
}