<?php


class ContactInfo
{
	public $phoneNumber;  //String
	public $mobilePhoneNumber;  //String
	public $email; //String
}