<?php 

class AvailabilityReq {
    public $language;
    public $stay;
    public $occupancies;
    public $hotels;
}