<div class="col-lg-12">
    <div class="panel panel-default">
        <div class="panel-heading"><?=$page_title?></div>
        <div class="panel-body">
            <h2>Index Page</h2>
        </div>
    </div>
</div>