@extends('frontend.layouts.app')

@section('content')

<div class="thankyou m-5" style="text-align: center;">
  <div class="container">
     <h3>Payment done successfully.</h3>
  </div>
</div>

@endsection