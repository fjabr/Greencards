<?php

class Foid
{
	public $no;  //String
	public $citizenhipCountry;  //String
}