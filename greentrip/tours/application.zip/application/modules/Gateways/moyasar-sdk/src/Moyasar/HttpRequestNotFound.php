<?php

/**
 * Created by PhpStorm.
 * User: Sohib
 * Date: 5/8/16
 * Time: 5:50 PM
 */
class HttpRequestNotFound extends \Exception
{
}