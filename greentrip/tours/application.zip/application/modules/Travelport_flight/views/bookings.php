<style>.delete_button{right: 0px; top: 44px;}</style>
<div class="row">
    <div class="col-md-12">
        <div class="panel panel-default">
            <div class="panel-heading">Flight Bookings</div>
            <div class="panel-body"><?php echo $content; ?></div>
            <div class="panel-footer"></div>
        </div>
    </div>
</div>