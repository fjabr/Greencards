
//
//  BagsPrice.php
//  Model Generated using http://www.jsoncafe.com/ 
//  Created on April 18, 2019
class BagsPrice
{

    public $1; //Integer
    
    public function get1() { 
         return $this->1; 
    }
    public function set1($1) { 
         $this->1 = $1; 
    }    

}