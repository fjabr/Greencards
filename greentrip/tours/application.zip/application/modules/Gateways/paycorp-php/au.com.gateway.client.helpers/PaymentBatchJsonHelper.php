<?php

class PaymentBatchJsonHelper {
    
}
