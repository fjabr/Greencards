<?php



class FlightFareReference
{
	public $itineraryId;  //String
	public $fareType;  //Enum String | PROMO, ECONOMY, BUSINESS
}