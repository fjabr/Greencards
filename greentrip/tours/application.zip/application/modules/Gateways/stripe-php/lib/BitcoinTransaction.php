<?php

namespace Stripe;

class BitcoinTransaction extends ApiResource
{

}
