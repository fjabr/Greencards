<?php 

class Iati_model extends CI_Model 
{
    
}