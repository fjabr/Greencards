<style>
  .passenger-list-iati {
      list-style: none;
      margin: 0px;
      padding: 0px;
  }
</style>
<div class="row">
    <div class="col-md-12">
        <div class="panel panel-default">
            <div class="panel-heading"></div>
            <div class="panel-body"><?php echo $content; ?></div>
            <div class="panel-footer"></div>
        </div>
    </div>
</div>