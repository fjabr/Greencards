@extends('backend.layouts.app')

@section('content')
<div class="aiz-titlebar text-left mt-2 mb-3">
    <div class="row align-items-center">
        <div class="col-md-6">
            <!--<h1 class="h3">Contracts</h1>-->
            
        </div>
        
    </div>
</div>
<div class="card">
    <div class="card-header d-block d-md-flex">
        <h5 class="mb-0 h6">Invoices Mobile</h5>
        
    </div>
    <div class="card-body">
        <table class="table aiz-table mb-0">
                <thead>
                    <tr>
                        <th >#</th>
                        <th>User Name</th>
                        <th>User Email</th>
                        <th>Amount</th>
                        <th>VAT Amount</th>
                        <th>Qr Code</th>
                        <th>Download</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($invoices as $key => $invoice)
                        <tr>
                            <td>{{ $invoice->id }}</td>
                            <td>{{ $invoice->userName }}</td>
                            <td>{{ $invoice->userEmail }}</td>
                            <td>
                                {{ $invoice->amount }}
                            </td>
                            <td>
                                {{ $invoice->vat_total }}
                            </td>
                            <td>
                                <img src="https://chart.googleapis.com/chart?chs=100x100&cht=qr&chl={{ $invoice->qr_code }}&choe=UTF-8" />
                            </td>
                            <td>
                                <a target="_blanck" href="{{ route('get_invoices', $invoice->id) }} " class="btn btn-primary" >Download</a>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
        </table>
    </div>
</div>
@endsection


@section('modal')
    @include('modals.delete_modal')
@endsection

