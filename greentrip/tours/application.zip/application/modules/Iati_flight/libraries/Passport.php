<?php


class Passport
{
	
	public $no; //String
	public $serial; //String
	
	public $issueDate; //Date || Format: YYYY-MM-DD
	public $endDate; //Date || Format: YYYY-MM-DD
	
	public $citizenhipCountry; //String
	public $issueCountry; //String
	
}