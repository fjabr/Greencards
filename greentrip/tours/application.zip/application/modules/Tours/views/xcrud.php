
    <script src="<?php echo base_url();?>assets/js/jquery-1.11.2.js"></script>
    <?php echo $content; ?>

    <link href="<?php echo base_url(); ?>assets/css/style.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/admin.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/fa.min.css" rel="stylesheet">